// Copyright Callback LLP. All Rights Reserved.
#include "Components/AtlasLuaComponent.h"
#include "Scripts/AtlasLuaScript.h"
#include "Internal/AtlasLuaExecution.h"
#include "GameFramework/Actor.h"

UAtlasLuaComponent::UAtlasLuaComponent() { PrimaryComponentTick.bCanEverTick = false; }
bool UAtlasLuaComponent::RunEvent(FGameplayTag Event, double Number, const FString& Text, FString& Error)
{
    return ExecuteEvent(Event, Number, Text, nullptr, Error);
}
bool UAtlasLuaComponent::RunEventWithContext(FGameplayTag Event, double Number, const FString& Text,
    const FAtlasVariantStore& Context, FString& Error)
{
    return ExecuteEvent(Event, Number, Text, &Context, Error);
}
bool UAtlasLuaComponent::ExecuteEvent(FGameplayTag Event, double Number, const FString& Text,
    const FAtlasVariantStore* Context, FString& Error)
{
    Error.Reset();
    if (!IsInGameThread() || bExecuting || bEnding || !IsRegistered() || !IsValid(GetOwner()) || !IsValid(Script))
    { Error = TEXT("Lua requires a registered, live, idle component with a script on the game thread."); return false; }
    if (!bPresentationOnly && !GetOwner()->HasAuthority())
    { Error = TEXT("Gameplay Lua events require authority."); return false; }
    if (!Event.IsValid()) { Error = TEXT("Lua event must be a registered gameplay tag."); return false; }
    TGuardValue<bool> Executing(bExecuting, true);
    FString NewState; TArray<FAtlasLuaSignal> Signals;
    if (!AtlasLuaExecution::Execute(*Script, Event.ToString(), Number, Text, StateJson, NewState, Signals, Error, false, Context)) return false;
    StateJson = MoveTemp(NewState);
    for (const auto& Signal : Signals)
    {
        if (bEnding || !IsRegistered() || !IsValid(GetOwner())) break;
        OnSignal.Broadcast(Signal);
    }
    return true;
}
void UAtlasLuaComponent::EndPlay(const EEndPlayReason::Type Reason)
{
    bEnding = true;
    OnSignal.Clear();
    Super::EndPlay(Reason);
}
