// Copyright Callback LLP. All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "Types/VariantDataTypes.h"
#include "AtlasLuaComponent.generated.h"
class UAtlasLuaScript;

/** Local output of a successful Lua event; it is not an RPC or a global gameplay message. */
USTRUCT(BlueprintType)
struct ATLASLUAFRAMEWORKRUNTIME_API FAtlasLuaSignal
{
    GENERATED_BODY()
    /** Registered gameplay tag used by the owning Blueprint to select a handler. */
    UPROPERTY(BlueprintReadOnly, Category="Lua") FGameplayTag Channel;
    /** Finite numeric argument, such as a count, multiplier, or elapsed time. */
    UPROPERTY(BlueprintReadOnly, Category="Lua") double Number = 0;
    /** Optional short text argument; never interpreted as a UObject path or command by the runtime. */
    UPROPERTY(BlueprintReadOnly, Category="Lua") FString Text;
};
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FAtlasLuaSignalEvent, const FAtlasLuaSignal&, Signal);

/** Explicit event-driven Lua behavior. Add through a Game Feature or an authored actor; no automatic disk saves. */
UCLASS(BlueprintType, Blueprintable, ClassGroup=(Scripting), meta=(BlueprintSpawnableComponent, DisplayName="Lua Behavior"))
class ATLASLUAFRAMEWORKRUNTIME_API UAtlasLuaComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UAtlasLuaComponent();
    /** Script executed for incoming events. Its source is cooked with the mod and covered by its artifact hash. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Lua") TObjectPtr<UAtlasLuaScript> Script;
    /** Opt in only for local presentation. Gameplay scripts run on the authoritative actor by default. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Lua") bool bPresentationOnly = false;
    /** Last successful state. Atlas Savable captures this SaveGame field with other component properties. */
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, SaveGame, Category="Lua|State", meta=(MultiLine=true)) FString StateJson = TEXT("{}");
    /** Signals are dispatched only after the complete event succeeds and its state passes validation. */
    UPROPERTY(BlueprintAssignable, Category="Lua") FAtlasLuaSignalEvent OnSignal;
    /** Runs one bounded event. Errors leave state unchanged and discard all queued signals. Reentrant calls fail. */
    UFUNCTION(BlueprintCallable, Category="Lua", meta=(DisplayName="Run Lua Event"))
    bool RunEvent(FGameplayTag Event, double Number, const FString& Text, FString& Error);
    /** API 2: passes a bounded data-only copy as the fifth Lua argument. Keys are registered tags.
     * Context changes are discarded; only the returned state and emitted signals are committed.
     * The caller reads public owner snapshots and removes its event subscriptions on teardown. */
    UFUNCTION(BlueprintCallable, Category="Lua", meta=(DisplayName="Run Lua Event with Context"))
    bool RunEventWithContext(FGameplayTag Event, double Number, const FString& Text,
        const FAtlasVariantStore& Context, FString& Error);
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
private:
    bool ExecuteEvent(FGameplayTag Event, double Number, const FString& Text,
        const FAtlasVariantStore* Context, FString& Error);
    bool bExecuting = false;
    bool bEnding = false;
};
