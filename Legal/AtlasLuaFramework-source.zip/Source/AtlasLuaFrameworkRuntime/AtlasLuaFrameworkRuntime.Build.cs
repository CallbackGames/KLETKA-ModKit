// Copyright Callback LLP. All Rights Reserved.
using System.IO;
using UnrealBuildTool;
public class AtlasLuaFrameworkRuntime : ModuleRules
{
    public AtlasLuaFrameworkRuntime(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.NoPCHs;
        bUseUnity = false;
        bEnableExceptions = true;
        PublicIncludePaths.Add(ModuleDirectory);
        PrivateIncludePaths.Add(Path.Combine(PluginDirectory, "ThirdParty", "Lua"));
        PublicDependencyModuleNames.AddRange(new[] { "Core", "CoreUObject", "Engine", "GameplayTags", "AtlasVariantDataFrameworkRuntime" });
        PrivateDependencyModuleNames.AddRange(new[] { "Json", "InputCore" });
        PrivateDefinitions.Add("_CRT_SECURE_NO_WARNINGS=1");
        // Each invocation owns its Lua state and updates hooks synchronously.
        // No OS signal handler accesses it; use Lua's override without signal.h.
        PrivateDefinitions.Add("l_signalT=int");
    }
}
