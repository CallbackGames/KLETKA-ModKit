// Copyright Callback LLP. All Rights Reserved.
#include "Internal/AtlasLuaExecution.h"
#include "Scripts/AtlasLuaScript.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Policies/CondensedJsonPrintPolicy.h"
// Lua is compiled as C++: errors must unwind through callbacks to lua_pcall.
// C linkage with MSVC /EHsc would incorrectly promise that these calls never throw.
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

namespace
{
constexpr int32 MaxStateCharacters = 65536;
constexpr int32 MaxNodes = 2048;
constexpr int32 MaxDepth = 16;
char JsonArrayMarker;
struct FCall
{
    SIZE_T Used = 0, Limit = 0;
    int32 Instructions = 0;
    const UAtlasLuaScript* Script = nullptr;
    const FString* Event = nullptr;
    const FString* Text = nullptr;
    double Number = 0;
    TSharedPtr<FJsonObject> State;
    TSharedPtr<FJsonObject> InputContext;
    TArray<FAtlasLuaSignal> Signals;
    bool bParseOnly = false, bAllowSignals = false;
};
// Context is copied before VM execution and cannot mutate the caller's store or any UObject.
bool PrepareInputContext(const FAtlasVariantStore* Input, TSharedPtr<FJsonObject>& Output, FString& Error)
{
    Output = MakeShared<FJsonObject>();
    if (!Input) return true;
    if (Input->GetEntries().Num() > 128)
    { Error = TEXT("Lua context exceeds 128 fields."); return false; }
    int32 Characters = 0;
    for (const FAtlasVariantStoreEntry& Entry : Input->GetEntries())
    {
        const FString Key = Entry.Key.ToString();
        const FAtlasVariantValue& Value = Entry.Value;
        if (!Entry.Key.IsValid() || Key.Len() > 256 || !Value.IsValid())
        { Error = TEXT("Lua context requires registered keys and valid finite values."); return false; }
        Characters += Key.Len();
        FString Text;
        bool bText = false;
        switch (Value.ValueType)
        {
        case EAtlasVariantValueType::Double:
            Output->SetNumberField(Key, Value.DoubleValue); break;
        case EAtlasVariantValueType::Bool:
            Output->SetBoolField(Key, Value.BoolValue); break;
        case EAtlasVariantValueType::Int32:
            Output->SetNumberField(Key, Value.IntValue); break;
        case EAtlasVariantValueType::Int64:
            if (Value.Int64Value > 9007199254740991LL || Value.Int64Value < -9007199254740991LL)
            { Error = TEXT("Lua context integer exceeds the exact JSON numeric range; pass an identity as text."); return false; }
            Output->SetNumberField(Key, static_cast<double>(Value.Int64Value)); break;
        case EAtlasVariantValueType::Name:
            Text = Value.NameValue.ToString(); bText = true; break;
        case EAtlasVariantValueType::String:
            Text = Value.StringValue; bText = true; break;
        case EAtlasVariantValueType::Key:
            Text = Value.KeyValue.GetFName().ToString(); bText = true; break;
        default:
            Error = TEXT("Unsupported Lua context value type."); return false;
        }
        if (bText)
        {
            if (Text.Len() > 4096)
            { Error = TEXT("Lua context text exceeds 4096 characters."); return false; }
            Characters += Text.Len();
            Output->SetStringField(Key, Text);
        }
        if (Characters > MaxStateCharacters)
        { Error = TEXT("Lua context exceeds the total text limit."); return false; }
    }
    return true;
}
FCall& Context(lua_State* L) { return **static_cast<FCall**>(lua_getextraspace(L)); }
FString ReadUtf8(lua_State* L, const char* Bytes, size_t Length)
{
    FUTF8ToTCHAR Converted(Bytes, static_cast<int32>(Length));
    FString Result(Converted.Length(), Converted.Get());
    FTCHARToUTF8 RoundTrip(*Result, Result.Len());
    if (static_cast<size_t>(RoundTrip.Length()) != Length || FMemory::Memcmp(RoundTrip.Get(), Bytes, Length) != 0)
        luaL_error(L,"Lua state and signal text must be valid UTF-8");
    return Result;
}
void* Allocate(void* User, void* Pointer, size_t OldSize, size_t NewSize)
{
    auto& Call = *static_cast<FCall*>(User);
    if (!Pointer) OldSize = 0;
    if (!NewSize) { FMemory::Free(Pointer); Call.Used -= OldSize; return nullptr; }
    if (NewSize > Call.Limit || Call.Used - OldSize > Call.Limit - NewSize) return nullptr;
    void* Result = FMemory::Realloc(Pointer, NewSize);
    if (Result) Call.Used = Call.Used - OldSize + NewSize;
    return Result;
}
void CheckInstructions(lua_State* L, lua_Debug*)
{
    Context(L).Instructions -= 1000;
    if (Context(L).Instructions <= 0) luaL_error(L, "Lua instruction budget exceeded");
}
void PushText(lua_State* L, const FString& Value)
{
    FTCHARToUTF8 Utf8(*Value, Value.Len());
    lua_pushlstring(L, Utf8.Get(), Utf8.Length());
}
void PushJson(lua_State* L, const TSharedPtr<FJsonValue>& Value, int32 Depth, int32& Nodes)
{
    if (++Nodes > MaxNodes || Depth > MaxDepth) luaL_error(L, "Lua state exceeds structural limits");
    if (!lua_checkstack(L, 8)) luaL_error(L, "Lua state exceeds stack capacity");
    if (!Value || Value->IsNull()) { luaL_error(L,"Lua state does not support JSON null values"); return; }
    switch (Value->Type)
    {
    case EJson::Boolean: lua_pushboolean(L, Value->AsBool()); break;
    case EJson::Number:
        if (!FMath::IsFinite(Value->AsNumber())) luaL_error(L, "Lua input numbers must be finite");
        lua_pushnumber(L, Value->AsNumber()); break;
    case EJson::String: PushText(L, Value->AsString()); break;
    case EJson::Array:
        lua_newtable(L);
        // Remember empty JSON arrays without exposing metatable access to scripts.
        lua_newtable(L); lua_pushboolean(L, 1); lua_rawsetp(L, -2, &JsonArrayMarker); lua_setmetatable(L, -2);
        for (int32 Index = 0; Index < Value->AsArray().Num(); ++Index)
        { PushJson(L, Value->AsArray()[Index], Depth+1, Nodes); lua_rawseti(L, -2, Index+1); }
        break;
    case EJson::Object:
        lua_newtable(L);
        for (const auto& Pair : Value->AsObject()->Values)
        { PushText(L, FString(Pair.Key.ToView())); PushJson(L, Pair.Value, Depth+1, Nodes); lua_rawset(L, -3); }
        break;
    default: luaL_error(L, "Unsupported Lua state value");
    }
}
TSharedPtr<FJsonValue> ReadJson(lua_State* L, int32 Index, int32 Depth, int32& Nodes, TSet<const void*>& Ancestors)
{
    if (++Nodes > MaxNodes || Depth > MaxDepth) luaL_error(L, "Lua result exceeds structural limits");
    if (!lua_checkstack(L, 8)) luaL_error(L, "Lua result exceeds stack capacity");
    Index = lua_absindex(L, Index);
    switch (lua_type(L, Index))
    {
    case LUA_TBOOLEAN: return MakeShared<FJsonValueBoolean>(lua_toboolean(L, Index) != 0);
    case LUA_TNUMBER:
    {
        double Value = lua_tonumber(L, Index);
        if (!FMath::IsFinite(Value)) luaL_error(L, "Lua state numbers must be finite");
        if (lua_isinteger(L,Index) && (lua_tointeger(L,Index) > 9007199254740991LL || lua_tointeger(L,Index) < -9007199254740991LL))
            luaL_error(L, "Lua saved integers must fit the exact JSON number range");
        return MakeShared<FJsonValueNumber>(Value);
    }
    case LUA_TSTRING:
    {
        size_t Bytes = 0; const char* Text = lua_tolstring(L, Index, &Bytes);
        if (Bytes > MaxStateCharacters) luaL_error(L, "Lua state string is too long");
        return MakeShared<FJsonValueString>(ReadUtf8(L, Text, Bytes));
    }
    case LUA_TTABLE:
    {
        const void* Identity = lua_topointer(L, Index);
        if (Ancestors.Contains(Identity)) luaL_error(L, "Lua state cannot contain cycles");
        Ancestors.Add(Identity);
        const size_t Length = lua_rawlen(L, Index);
        bool bArray = Length > 0;
        if (lua_getmetatable(L, Index))
        {
            lua_rawgetp(L, -1, &JsonArrayMarker); bArray |= lua_toboolean(L, -1) != 0; lua_pop(L, 2);
        }
        if (Length > MaxNodes) luaL_error(L, "Lua state array is too large");
        TArray<TSharedPtr<FJsonValue>> Array;
        auto Object = MakeShared<FJsonObject>();
        int32 Count = 0;
        lua_pushnil(L);
        while (lua_next(L, Index))
        {
            ++Count;
            if (bArray)
            {
                if (!lua_isinteger(L, -2) || lua_tointeger(L,-2) < 1 || lua_tointeger(L,-2) > static_cast<lua_Integer>(Length))
                    luaL_error(L, "Lua arrays must have contiguous integer keys and no named fields");
            }
            else
            {
                if (lua_type(L,-2) != LUA_TSTRING) luaL_error(L, "Lua state objects require string keys");
                size_t Bytes = 0; const char* Key = lua_tolstring(L,-2,&Bytes);
                if (Bytes > 256) luaL_error(L, "Lua state key is too long");
                FString Name = ReadUtf8(L, Key, Bytes);
                Object->SetField(Name, ReadJson(L,-1,Depth+1,Nodes,Ancestors));
            }
            lua_pop(L,1);
            if (Count > MaxNodes) luaL_error(L, "Lua state has too many fields");
        }
        if (bArray)
        {
            if (Count != static_cast<int32>(Length)) luaL_error(L, "Lua state arrays cannot contain holes");
            for (int32 I=1; I<=Count; ++I)
            { lua_rawgeti(L,Index,I); Array.Add(ReadJson(L,-1,Depth+1,Nodes,Ancestors)); lua_pop(L,1); }
        }
        Ancestors.Remove(Identity);
        if (bArray) return MakeShared<FJsonValueArray>(Array);
        return MakeShared<FJsonValueObject>(Object);
    }
    default: luaL_error(L, "Lua saved state supports booleans, numbers, strings, arrays, and objects only"); return nullptr;
    }
}
int Emit(lua_State* L)
{
    auto& Call = Context(L);
    if (!Call.bAllowSignals || Call.Signals.Num() >= 64) return luaL_error(L,"Lua signal limit exceeded or emit outside an event");
    size_t TagBytes = 0, TextBytes = 0;
    const char* Tag = luaL_checklstring(L,1,&TagBytes);
    double Number = luaL_optnumber(L,2,0);
    const char* Text = luaL_optlstring(L,3,"",&TextBytes);
    if (TagBytes > 256 || TextBytes > 4096 || !FMath::IsFinite(Number)) return luaL_error(L,"Invalid Lua signal arguments");
    FString TagText = ReadUtf8(L, Tag, TagBytes);
    if (FCString::Strlen(*TagText) != TagText.Len()) return luaL_error(L,"Lua signal tags cannot contain NUL");
    FName ExistingName(*TagText,FNAME_Find);
    FGameplayTag Channel = ExistingName.IsNone() ? FGameplayTag() : FGameplayTag::RequestGameplayTag(ExistingName,false);
    if (!Channel.IsValid()) return luaL_error(L,"Lua signals require a registered gameplay tag");
    FAtlasLuaSignal& Signal = Call.Signals.AddDefaulted_GetRef();
    Signal.Channel = Channel; Signal.Number = Number;
    Signal.Text = ReadUtf8(L, Text, TextBytes);
    return 0;
}
void CopyFields(lua_State* L, int From, int To, const char* const* Names)
{
    From=lua_absindex(L,From); To=lua_absindex(L,To);
    for (; *Names; ++Names) { lua_getfield(L,From,*Names); lua_setfield(L,To,*Names); }
}
void OpenEnvironment(lua_State* L)
{
    luaL_requiref(L,"_G",luaopen_base,1); lua_pop(L,1);
    lua_newtable(L); int Env=lua_gettop(L);
    lua_pushglobaltable(L);
    static const char* const Base[] = {"assert","error","ipairs","next","pairs","select","tonumber","tostring","type","_VERSION",nullptr};
    CopyFields(L,-1,Env,Base); lua_pop(L,1);
    luaL_requiref(L,"math",luaopen_math,0);
    lua_pushnil(L); lua_setfield(L,-2,"random"); lua_pushnil(L); lua_setfield(L,-2,"randomseed");
    lua_setfield(L,Env,"math");
    luaL_requiref(L,"string",luaopen_string,0); int Strings=lua_gettop(L);
    lua_newtable(L);
    static const char* const String[] = {"byte","char","len","lower","upper","reverse","sub",nullptr};
    CopyFields(L,Strings,-1,String);
    // The string metatable must expose the same restricted functions as the environment.
    lua_pushliteral(L,""); lua_getmetatable(L,-1); lua_pushvalue(L,-3); lua_setfield(L,-2,"__index"); lua_pop(L,2);
    lua_setfield(L,Env,"string"); lua_pop(L,1);
    luaL_requiref(L,"table",luaopen_table,0); int Tables=lua_gettop(L); lua_newtable(L);
    static const char* const Table[] = {"concat","insert","remove",nullptr};
    CopyFields(L,Tables,-1,Table); lua_setfield(L,Env,"table"); lua_pop(L,1);
    lua_newtable(L); lua_pushcfunction(L,Emit); lua_setfield(L,-2,"emit"); lua_setfield(L,Env,"atlas");
}
int RunProtected(lua_State* L)
{
    FCall& Call=Context(L);
    OpenEnvironment(L); const int Env=lua_gettop(L);
    FTCHARToUTF8 Source(*Call.Script->SourceCode, Call.Script->SourceCode.Len());
    if (luaL_loadbufferx(L,Source.Get(),Source.Length(),"mod.lua","t") != LUA_OK) return lua_error(L);
    if (Call.bParseOnly) return 0;
    lua_pushvalue(L,Env); lua_setupvalue(L,-2,1);
    lua_call(L,0,1);
    if (!lua_isfunction(L,-1)) return luaL_error(L,"Lua source must return function(event, number, text, state)");
    PushText(L,*Call.Event); lua_pushnumber(L,Call.Number); PushText(L,*Call.Text);
    int32 Nodes=0; PushJson(L,MakeShared<FJsonValueObject>(Call.State),0,Nodes);
    const bool bContextApi = Call.Script->ApiVersion == 2;
    if (bContextApi)
    {
        Nodes = 0;
        PushJson(L, MakeShared<FJsonValueObject>(Call.InputContext), 0, Nodes);
    }
    Call.bAllowSignals=true;
    lua_call(L,bContextApi ? 5 : 4,1);
    Call.bAllowSignals=false;
    Nodes=0; TSet<const void*> Ancestors;
    const auto Value=ReadJson(L,-1,0,Nodes,Ancestors);
    if (!Value.IsValid() || Value->Type != EJson::Object) return luaL_error(L,"Lua handler must return an object as saved state");
    Call.State=Value->AsObject();
    return 0;
}
}

bool AtlasLuaExecution::Execute(const UAtlasLuaScript& Script, const FString& Event, double Number,
    const FString& Text, const FString& StateJson, FString& OutState, TArray<FAtlasLuaSignal>& OutSignals, FString& Error, bool bParseOnly, const FAtlasVariantStore* InputContext)
{
    Error.Reset(); OutSignals.Reset();
    if ((Script.ApiVersion != 1 && Script.ApiVersion != 2) || Script.SourceCode.Len() > 65536 || Text.Len() > 4096 || Event.Len() > 256
        || StateJson.Len() > MaxStateCharacters || !FMath::IsFinite(Number))
    { Error=TEXT("Unsupported Lua API version or oversized/non-finite input."); return false; }
    if (InputContext && Script.ApiVersion != 2)
    { Error = TEXT("Run Lua Event with Context requires Lua API 2."); return false; }
    FCall Call;
    if (!PrepareInputContext(InputContext, Call.InputContext, Error)) return false;
    // Bound nesting before handing text to the recursive JSON parser.
    int32 Nesting = 0; bool InString = false, Escaped = false;
    for (const TCHAR Character : StateJson)
    {
        if (InString)
        {
            if (Escaped) Escaped=false;
            else if (Character==TEXT('\\')) Escaped=true;
            else if (Character==TEXT('"')) InString=false;
        }
        else if (Character==TEXT('"')) InString=true;
        else if (Character==TEXT('{') || Character==TEXT('['))
        {
            if (++Nesting > MaxDepth) { Error=TEXT("Lua input state is nested too deeply."); return false; }
        }
        else if (Character==TEXT('}') || Character==TEXT(']')) --Nesting;
    }
    if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(StateJson),Call.State) || !Call.State)
    { Error=TEXT("Lua state must be a valid JSON object."); return false; }
    Call.Limit=static_cast<SIZE_T>(FMath::Clamp(Script.MemoryLimitKiB,256,8192))*1024;
    Call.Instructions=FMath::Clamp(Script.InstructionLimit,1000,1000000);
    Call.Script=&Script; Call.Event=&Event; Call.Text=&Text; Call.Number=Number; Call.bParseOnly=bParseOnly;
    lua_State* L=lua_newstate(Allocate,&Call,0x41544c53u);
    if (!L) { Error=TEXT("Lua state allocation failed."); return false; }
    *static_cast<FCall**>(lua_getextraspace(L))=&Call;
    lua_sethook(L,CheckInstructions,LUA_MASKCOUNT,1000);
    lua_pushcfunction(L,RunProtected);
    const int Status=lua_pcall(L,0,0,0);
    if (Status != LUA_OK)
    {
        const char* Message=lua_type(L,-1)==LUA_TSTRING ? lua_tostring(L,-1) : "Lua execution failed";
        Error=UTF8_TO_TCHAR(Message);
    }
    lua_close(L);
    if (Status != LUA_OK) return false;
    FString Result;
    if (!FJsonSerializer::Serialize(Call.State.ToSharedRef(),TJsonWriterFactory<TCHAR,TCondensedJsonPrintPolicy<TCHAR>>::Create(&Result)) || Result.Len() > MaxStateCharacters)
    { Error=TEXT("Lua resulting state exceeds the save limit."); return false; }
    OutState=MoveTemp(Result); OutSignals=MoveTemp(Call.Signals);
    return true;
}
