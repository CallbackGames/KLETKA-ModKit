// Copyright Callback LLP. All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "Components/AtlasLuaComponent.h"
class UAtlasLuaScript;
/** Internal data-only interpreter boundary, also exercised by the runtime's regression tests. */
namespace AtlasLuaExecution
{
    ATLASLUAFRAMEWORKRUNTIME_API bool Execute(const UAtlasLuaScript& Script, const FString& Event,
        double Number, const FString& Text, const FString& StateJson, FString& OutState,
        TArray<FAtlasLuaSignal>& OutSignals, FString& Error, bool bParseOnly = false, const FAtlasVariantStore* InputContext = nullptr);
}
