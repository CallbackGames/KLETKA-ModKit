// Copyright Callback LLP. All Rights Reserved.
// Lua source and license: ThirdParty/Lua. Compile as C++ for exception-safe error unwinding.
// Upstream error macros intentionally leave unreachable returns after a C++ throw.
#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4702)
#endif
#include "lauxlib.c"

#if defined(_MSC_VER)
#pragma warning(pop)
#endif
