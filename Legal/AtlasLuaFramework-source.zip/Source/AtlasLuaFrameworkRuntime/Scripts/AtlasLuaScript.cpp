// Copyright Callback LLP. All Rights Reserved.
#include "Scripts/AtlasLuaScript.h"
#include "Internal/AtlasLuaExecution.h"
#if WITH_EDITOR
#include "Misc/DataValidation.h"
#endif
bool UAtlasLuaScript::ValidateSource(FString& Error) const
{
    FString State; TArray<FAtlasLuaSignal> Signals;
    return AtlasLuaExecution::Execute(*this, FString(), 0, FString(), TEXT("{}"), State, Signals, Error, true);
}
#if WITH_EDITOR
EDataValidationResult UAtlasLuaScript::IsDataValid(FDataValidationContext& Context) const
{
    FString Error;
    if (!ValidateSource(Error)) { Context.AddError(FText::FromString(GetPathName() + TEXT(": ") + Error)); return EDataValidationResult::Invalid; }
    return Super::IsDataValid(Context) == EDataValidationResult::Invalid ? EDataValidationResult::Invalid : EDataValidationResult::Valid;
}
#endif
