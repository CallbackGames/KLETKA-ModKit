// Copyright Callback LLP. All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "AtlasLuaScript.generated.h"

/** Lua source compiled into cooked content. Return a function(event, number, text, state) that returns state. */
UCLASS(BlueprintType, meta=(ToolTip="Lua event handler for an Atlas Lua component. Scripts receive plain data and emit local signals; the owning Blueprint calls gameplay APIs."))
class ATLASLUAFRAMEWORKRUNTIME_API UAtlasLuaScript : public UDataAsset
{
    GENERATED_BODY()
public:
    /** API 1 receives event/number/text/state. API 2 adds a data-only context table as the fifth argument.
     * Existing scripts remain API 1 until explicitly changed. Unsupported versions fail before execution. */
    UPROPERTY(EditAnywhere, Category="Compatibility", meta=(ClampMin="1", ClampMax="2", DisplayName="Lua API Version")) int32 ApiVersion = 1;
    /** Return function(event, number, text, state). Use atlas.emit(tag, number, text) for local output signals. */
    UPROPERTY(EditAnywhere, Category="Script", meta=(MultiLine=true)) FString SourceCode = TEXT("return function(event, number, text, state)\n    return state\nend\n");
    /** Per-event Lua allocation ceiling, including source and result tables. Never grants file, network, or UObject access. */
    UPROPERTY(EditAnywhere, Category="Limits", meta=(ClampMin="256", ClampMax="8192", Units="KiB")) int32 MemoryLimitKiB = 2048;
    /** Per-event VM instruction ceiling, including top-level script initialization. */
    UPROPERTY(EditAnywhere, Category="Limits", meta=(ClampMin="1000", ClampMax="1000000")) int32 InstructionLimit = 100000;
    /** Parses source as text. Runtime budgets and result validation are checked when an event executes. */
    bool ValidateSource(FString& Error) const;
#if WITH_EDITOR
    virtual EDataValidationResult IsDataValid(FDataValidationContext& Context) const override;
#endif
};
