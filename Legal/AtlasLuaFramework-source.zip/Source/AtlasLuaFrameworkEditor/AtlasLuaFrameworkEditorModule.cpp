// Copyright Callback LLP. All Rights Reserved.
#include "Modules/ModuleManager.h"
IMPLEMENT_MODULE(FDefaultModuleImpl, AtlasLuaFrameworkEditor)
