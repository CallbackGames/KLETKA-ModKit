// Copyright Callback LLP. All Rights Reserved.
using UnrealBuildTool;
public class AtlasLuaFrameworkEditor : ModuleRules
{
    public AtlasLuaFrameworkEditor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateIncludePaths.Add(ModuleDirectory);
        PrivateDependencyModuleNames.AddRange(new[] { "Core", "CoreUObject", "Engine", "UnrealEd", "AssetDefinition", "AssetTools", "AtlasLuaFrameworkRuntime" });
    }
}
