// Copyright Callback LLP. All Rights Reserved.
#pragma once
#include "Factories/Factory.h"
#include "AssetDefinitionDefault.h"
#include "AtlasLuaScriptFactory.generated.h"

/** Creates a cooked Lua script asset or imports a UTF-8 Lua source file. */
UCLASS(meta=(DisplayName="Lua Script", ToolTip="Create or import a Lua event handler. Add Lua Behavior to an actor and assign this script."))
class UAtlasLuaScriptFactory : public UFactory
{
    GENERATED_BODY()
public:
    UAtlasLuaScriptFactory();
    virtual FText GetDisplayName() const override;
    virtual uint32 GetMenuCategories() const override;
    virtual TArray<FAssetCategoryPath> GetAssetMenuPathsForCategory(FName InCategory) const override;
    virtual UObject* FactoryCreateNew(UClass* Class, UObject* Parent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
    virtual UObject* FactoryCreateText(UClass* Class, UObject* Parent, FName Name, EObjectFlags Flags, UObject* Context, const TCHAR* Type, const TCHAR*& Buffer, const TCHAR* BufferEnd, FFeedbackContext* Warn) override;
};

UCLASS()
class UAssetDefinition_AtlasLuaScript : public UAssetDefinitionDefault
{
    GENERATED_BODY()
public:
    virtual FText GetAssetDisplayName() const override;
    virtual FLinearColor GetAssetColor() const override;
    virtual TSoftClassPtr<UObject> GetAssetClass() const override;
    virtual TConstArrayView<FAssetCategoryPath> GetAssetCategories() const override;
};
