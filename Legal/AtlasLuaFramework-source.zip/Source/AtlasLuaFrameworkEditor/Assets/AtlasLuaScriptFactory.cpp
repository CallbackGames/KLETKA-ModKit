// Copyright Callback LLP. All Rights Reserved.
#include "Assets/AtlasLuaScriptFactory.h"
#include "AssetToolsModule.h"
#include "IAssetTools.h"
#include "Misc/AssetCategoryPath.h"
#include "Modules/ModuleManager.h"
#include "Scripts/AtlasLuaScript.h"
#include "Misc/FeedbackContext.h"

UAtlasLuaScriptFactory::UAtlasLuaScriptFactory()
{
    SupportedClass=UAtlasLuaScript::StaticClass(); bCreateNew=true; bEditAfterNew=true;
    bEditorImport=true; bText=true; Formats.Add(TEXT("lua;Lua event script"));
}
FText UAtlasLuaScriptFactory::GetDisplayName() const { return GetSupportedClass()->GetDisplayNameText(); }
uint32 UAtlasLuaScriptFactory::GetMenuCategories() const
{
    return FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools")).Get()
        .RegisterAdvancedAssetCategory(TEXT("Atlas"), INVTEXT("Atlas"));
}
TArray<FAssetCategoryPath> UAtlasLuaScriptFactory::GetAssetMenuPathsForCategory(FName InCategory) const
{
    return { FAssetCategoryPath(FAssetCategoryPath(FText::FromName(InCategory)), INVTEXT("Scripting")) };
}
UObject* UAtlasLuaScriptFactory::FactoryCreateNew(UClass* Class, UObject* Parent, FName Name, EObjectFlags Flags, UObject*, FFeedbackContext*)
{
    return NewObject<UAtlasLuaScript>(Parent,Class,Name,Flags|RF_Transactional);
}
UObject* UAtlasLuaScriptFactory::FactoryCreateText(UClass* Class, UObject* Parent, FName Name, EObjectFlags Flags, UObject*, const TCHAR*, const TCHAR*& Buffer, const TCHAR* BufferEnd, FFeedbackContext* Warn)
{
    if (BufferEnd-Buffer > 65536) { if (Warn) Warn->Logf(ELogVerbosity::Error,TEXT("Lua source exceeds 65536 characters.")); return nullptr; }
    auto* Candidate=NewObject<UAtlasLuaScript>();
    Candidate->SourceCode=FString(static_cast<int32>(BufferEnd-Buffer),Buffer);
    FString Error;
    if (!Candidate->ValidateSource(Error)) { if (Warn) Warn->Logf(ELogVerbosity::Error,TEXT("%s"),*Error); return nullptr; }
    auto* Asset=NewObject<UAtlasLuaScript>(Parent,Class,Name,Flags|RF_Transactional);
    Asset->SourceCode=Candidate->SourceCode;
    return Asset;
}
FText UAssetDefinition_AtlasLuaScript::GetAssetDisplayName() const { return UAtlasLuaScript::StaticClass()->GetDisplayNameText(); }
FLinearColor UAssetDefinition_AtlasLuaScript::GetAssetColor() const { return FLinearColor(0.25f,0.45f,0.85f); }
TSoftClassPtr<UObject> UAssetDefinition_AtlasLuaScript::GetAssetClass() const { return UAtlasLuaScript::StaticClass(); }
TConstArrayView<FAssetCategoryPath> UAssetDefinition_AtlasLuaScript::GetAssetCategories() const
{
    static const FAssetCategoryPath Categories[]={FAssetCategoryPath(FAssetCategoryPath(INVTEXT("Atlas")),INVTEXT("Scripting"))};
    return Categories;
}
